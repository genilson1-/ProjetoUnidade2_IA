# -*- coding:utf-8 -*-

from pygraphviz import AGraph

from __init__ import PL_INSTANCE as prolog
from __init__ import REGRAS


def to_pygraphviz(elist, regra):
    graph = AGraph(directed=True, prog='dot')
    graph.add_edges_from(elist, label=REGRAS[regra])
    graph.node_attr['shape'] = 'box'
    return graph

def query(regra, arg1, arg2):
    '''
    Executa a query no prolog e identifica o tipo de query para conversão
    para formato graphviz
    '''
    qs_mount = '{0}({1},{2})'.format(regra, arg1, arg2)
    qs = prolog.query(qs_mount)

    elist = []

    if arg1.isupper() and arg2.isupper():
        elist = [(d[arg1], d[arg2]) for d in qs]
    elif not arg1.isupper() and not arg2.isupper():
        elist = [(arg1, arg2)] if list(qs) else []
    else:
        res = list(qs)
        parent = arg1 if not arg1.isupper() else arg2
        if res:
            elist = [(parent, d.values()[0]) for d in res]

    return elist
