homem(joao).
homem(pedro).
homem(joaquim).
homem(jose).
homem(astolfo).

mulher(maria).
mulher(ana).
mulher(astrogilda).

pai_de(joao, maria).
pai_de(joao, ana).
pai_de(joao, joaquim).
pai_de(pedro, luiza).
pai_de(pedro, carla).
pai_de(astolfo, joao).
pai_de(astolfo, pedro).
pai_de(X, Y):- homem(X), casado_com(X, Z), mae_de(Z, Y).

mae_de(maria, jose).
mae_de(X, Y):- mulher(X), casado_com(X, Z), pai_de(Z, Y).

casado_com(astrogilda, joao).
casado_com(jose, pedro).

filho_de(X, Y):- pai_de(Y, X).
filho_de(X, Y):- casado_com(Y, Z), pai_de(Z, X).

irmao_de(X, Y):- pai_de(Z, X), pai_de(Z, Y), X \= Y.

avo_de(X, Y):- pai_de(Z, Y), pai_de(X, Z).

neto_de(X, Y):- filho_de(Z, Y), pai_de(Z, X).

tio_de(X, Y):- irmao_de(X, Z), pai_de(Z, Y).

sobrinho_de(X, Y):- pai_de(Z, X), irmao_de(Z, Y).

primo_de(X, Y):- pai_de(Z, X), pai_de(W, Y), irmao_de(Z, W).
pai_de(pedro, antonio).
amante(pedro, antonio).
