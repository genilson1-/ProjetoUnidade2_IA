import re

from settings import BASE
from pyswip import Prolog

def get_regras():
    preds = []
    regex_regra = re.compile(r'^\w+')
    regex_pred = re.compile(r'\_.*')
    with open(BASE) as f:
        linha = f.readline()
        while linha:
            pred = regex_regra.search(linha)
            if pred and pred.group() not in preds:
                preds.append(pred.group())
            linha = f.readline()

    pred_dict = {}
    for pred in preds:
        pred_dict[pred] = regex_pred.sub('', pred).title()
    return pred_dict


PL_INSTANCE = Prolog()
PL_INSTANCE.consult(BASE)

REGRAS = get_regras()

def reset():
    PL_INSTANCE.consult(BASE)
    REGRAS.update({})
    REGRAS.update(get_regras())
