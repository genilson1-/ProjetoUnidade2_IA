#!/usr/bin/env python2
import re

import pygtk
pygtk.require('2.0')
import gtk

import xdot

from __init__ import REGRAS, BASE, reset

from utils import query
from utils import to_pygraphviz


class DotWindow(xdot.DotWindow):
    def __init__(self):
        xdot.DotWindow.__init__(self)


class AddRegra(gtk.Window):
    def nova_regra_callback(self, widget, nova_regra):
        with open(BASE, 'a') as f:
            f.write(nova_regra.get_text() + '\n')
        reset()

        regex_pred = re.compile(r'^\w+')
        regra = regex_pred.search(nova_regra.get_text())
        if regra:
            FM.combobox.append_text(regra.group())

    def __init__(self):
        gtk.Window.__init__(self)

        window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        window.set_size_request(300, 200)
        window.set_title('Genealogy - Adicionar Regra')
        window.connect('delete_event', lambda w, e: gtk.main_quit())

        vbox = gtk.VBox(False, 0)
        window.add(vbox)
        vbox.show()

        nova_regra = gtk.Entry()
        nova_regra.set_max_length(70)
        nova_regra.select_region(0, len(nova_regra.get_text()))
        vbox.pack_start(nova_regra, True, True, 0)
        nova_regra.show()

        button = gtk.Button('Criar nova regra')
        button.connect("clicked", self.nova_regra_callback, nova_regra)
        vbox.pack_start(button, True, True, 0)
        button.set_flags(gtk.CAN_DEFAULT)
        button.grab_default()
        button.show()

        window.show_all()


class FamilyGenealogy:
    def query_callback(self, widget, arg1, arg2):
        regra = self.active_text
        qs = query(regra, arg1.get_text(), arg2.get_text())
        graph = to_pygraphviz(qs, regra)

        dot = graph.string()
        window2 = DotWindow()
        window2.set_dotcode(dot)
        window2.connect('destroy', gtk.main_quit)
        window2.show()
        gtk.main()

    def get_active_text(self, combobox):
        model = combobox.get_model()
        active = combobox.get_active()
        if active < 0:
            return None
        self.active_text = model[active][0]

    def adicionar_regra(self, widget):
        AddRegra()
        gtk.main()

    def __init__(self):
        window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        window.set_size_request(300, 200)
        window.set_title('Genealogy')
        window.connect('delete_event', lambda w, e: gtk.main_quit())

        vbox = gtk.VBox(False, 0)
        window.add(vbox)
        vbox.show()

        menu = gtk.MenuBar()

        file_menu = gtk.Menu()
        add_menu = gtk.MenuItem("File")
        add_menu.set_submenu(file_menu)

        add_regra = gtk.MenuItem("Adicionar Regra")
        add_regra.connect("activate", self.adicionar_regra)

        exit = gtk.MenuItem("Sair")
        exit.connect("activate", gtk.main_quit)

        file_menu.append(add_regra)
        file_menu.append(exit)

        menu.append(add_menu)

        vbox.pack_start(menu, True, True, 0)

        regras = REGRAS.keys()
        self.active_text = ''
        self.combobox = gtk.combo_box_new_text()
        self.combobox.append_text('Selecione um tipo de consulta: ')
        for regra in regras:
            self.combobox.append_text(regra)
        self.combobox.connect('changed', self.get_active_text)
        self.combobox.set_active(0)
        vbox.add(self.combobox)

        arg1 = gtk.Entry()
        arg1.set_max_length(50)
        arg1.select_region(0, len(arg1.get_text()))
        vbox.pack_start(arg1, True, True, 0)
        arg1.show()

        arg2 = gtk.Entry()
        arg2.set_max_length(50)
        arg2.select_region(0, len(arg2.get_text()))
        vbox.pack_start(arg2, True, True, 0)
        arg2.show()

        hbox = gtk.HBox(False, 0)
        vbox.add(hbox)
        hbox.show()

        button = gtk.Button('Consultar')
        button.connect("clicked", self.query_callback, arg1, arg2)
        vbox.pack_start(button, True, True, 0)
        button.set_flags(gtk.CAN_DEFAULT)
        button.grab_default()
        button.show()
        window.show_all()


def main():
    gtk.main()
    return 0

if __name__ == "__main__":
    FM = FamilyGenealogy()
    main()
